// import { useState, useEffect } from 'react';

// function useDisplay(quantidade, array) {
//   const [newArr, setNewArr] = useState([]);

//   const display = () => {
//     const arr = [];
//     for (let index = 0; index < quantidade; index += 1) {
//       if (array[index]) {
//         arr.push(array[index]);
//       }
//     }
//     setNewArr(arr);
//   };

//   useEffect(() => {
//     display();
//   }, []);

//   return { newArr };
// }

// export default useDisplay;
