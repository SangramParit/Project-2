import { createContext } from 'react';

const RecipesAppContext = createContext();

export default RecipesAppContext;
