const PROTOCOL = process.env.REACT_APP_API_PROTOCOL || 'http://';
const HOST = process.env.REACT_APP_API_HOST || 'localhost:3001';
const LOCAL = process.env.REACT_APP_API_HOST_LOCAL || 'localhost:3000';
export { PROTOCOL, HOST, LOCAL };
// x
